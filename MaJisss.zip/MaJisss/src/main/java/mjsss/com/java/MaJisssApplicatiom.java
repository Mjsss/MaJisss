package mjsss.com.java;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import static org.springframework.boot.SpringApplication.run;

@SpringBootApplication
public class MaJisssApplicatiom {
    public static void main(String[] args) {
        run(MaJisssApplicatiom.class, args);
    }

}

